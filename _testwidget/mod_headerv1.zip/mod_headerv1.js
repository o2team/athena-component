'use strict';

/**
 * @author zhangtaizhen
 * @date 2016-4-19
 * @desc 公共头v1
 */
